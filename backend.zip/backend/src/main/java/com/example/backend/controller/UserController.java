package com.example.backend.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.backend.entity.User;
import com.example.backend.payload.UserDto;
import com.example.backend.repository.UserRepo;


@RestController
@RequestMapping("/user")
public class UserController {
	
	
	@Autowired
	UserRepo userRepo;
	
	
	@PostMapping("/register")
	public ResponseEntity<User> saveUser(@RequestBody User user)
	{
		return new ResponseEntity<>(userRepo.save(user),HttpStatus.ACCEPTED);
	}
	
	@GetMapping("/{userId}")
	public ResponseEntity<User> getUserById(@PathVariable long userId) {
	    Optional<User> userOptional = userRepo.findById(userId);

	    if (userOptional.isPresent()) {
	        return new ResponseEntity<>(userOptional.get(), HttpStatus.OK);
	    } else {
	        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	    }
	}
	
	@PutMapping("/update/{userId}")
	public ResponseEntity<User> updateUserById(@PathVariable long userId,@RequestBody UserDto userDto)
	{
		Optional<User> userOptional = userRepo.findById(userId);
		
		if(userOptional.isPresent())
		{
			userOptional.get().setEmail(userDto.getEmail());
			userOptional.get().setPassword(userDto.getPassword());
			userOptional.get().setUsername(userDto.getUsername());
			return new ResponseEntity<>(userRepo.save(userOptional.get()),HttpStatus.OK);
		}
		
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
	
	
	@DeleteMapping("/delete/{userId}")
	public ResponseEntity<Void> deleteUserById(@PathVariable long userId)
	{
		Optional<User> userOptional = userRepo.findById(userId);
		
		if(userOptional.isPresent())
		{
			userRepo.deleteById(userId);
			return new ResponseEntity<>(HttpStatus.OK);
		}
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		
	}
	

	
	
	
	
	
	

}
