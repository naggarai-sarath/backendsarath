package com.gokul.shopebackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShopEBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(ShopEBackendApplication.class, args);
    }

}
