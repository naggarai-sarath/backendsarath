package com.gokul.shopebackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopEBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
