# shop-e-online-store
springboot ,MySQL, Reactjs ecommerce app

# developmet stages can be found at :[Trello](https://trello.com/b/eiQFP5Q2)
# initial db:
![initial db schema](https://github.com/gokintosh/shop-e-online-store/blob/main/Untitled.png?raw=true)



